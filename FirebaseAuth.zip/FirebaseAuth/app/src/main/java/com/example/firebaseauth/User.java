package com.example.firebaseauth;

public class User {
    public String fullName, Email;


    public User(){

    }

    public User(String fullName, String Email){
        this.fullName= fullName;
        this.Email=Email;
    }
}
