package com.example.firebaseauth;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private TextView signUp;
    private EditText email, pass;
    private Button signIn;

    private FirebaseAuth mAuth;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signUp=(TextView) findViewById(R.id.signUp);
        signUp.setOnClickListener(this);

        signIn= findViewById(R.id.signIn);
        signIn.setOnClickListener(this);

        email= (EditText) findViewById(R.id.email);
        pass= (EditText)  findViewById(R.id.pass);

        mAuth = FirebaseAuth.getInstance();

        progressBar= (ProgressBar) findViewById(R.id.progressBar);


    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.signUp:
                startActivity(new Intent(this, User_Registration.class));
                break;
            case R.id.signIn:
                userLogin();
                break;
        }

    }

    private void userLogin() {
        String Email = email.getText().toString().trim();
        String Password = pass.getText().toString().trim();

        if(Email.isEmpty()){
            email.setError("Email is must!! ");
            email.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(Email).matches()){
            email.setError("Please Enter a Valid Email");
            email.requestFocus();
            return;
        }

        if(Password.isEmpty()){
            pass.setError("A Password must be given");
            pass.requestFocus();
            return;
        }

        if(Password.length()<8){
            pass.setError("Minimum password length should be 8 characters!!");
            pass.requestFocus();
            return;

        }

        progressBar.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(Email, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    startActivity(new Intent(MainActivity.this, Profile.class));
                }
                else {
                    Toast.makeText(MainActivity.this,"Incorrect Login... Please Try Again ",Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
    }
}